//
//  Clicktale.h
//  Clicktale
//
//  Created by Omer Blumenkrunz on 22/12/2016.
//  Copyright (c) 2017 Clicktale, Inc. All rights reserved.
//  Version : 2.1.5

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@class CLLocation;
typedef enum CT_LOG_LEVEL
{
    CT_LOG_LEVEL_NONE,
    CT_LOG_LEVEL_WARNING,
    CT_LOG_LEVEL_INFO,
    CT_LOG_LEVEL_ALL,
    CT_LOG_LEVEL_REQUIRED
}CT_LOG_LEVEL;


typedef enum CT_QUALITY
{
    CT_QUALITY_LOW,
    CT_QUALITY_LOW_PLUS,
    CT_QUALITY_MEDIUM,
    CT_QUALITY_MEDIUM_PLUS,
    CT_QUALITY_HIGH,
    CT_QUALITY_HIGH_PLUS,
    CT_QUALITY_HD
}CT_QUALITY;


@protocol ClicktaleDelegate <NSObject>
@optional

/**
 SDK did start running,
 you can now track events and screen recording will start
 */
- (void) clicktaleDidStart;

/**
 SDK did fail to start
 */
- (void) clicktaleDidFail;

/**
 Current session ID
 
 @param currentSessionID  NSString Session ID.
 */
- (void) clicktaleDidSessionIDCreated:(NSString *)currentSessionID;

/**
 Current session dashboard URL
 
 @param sessionLink  NSString dashboard URL.
 */
- (void) clicktaleDidSessionURLCreated:(NSString *)sessionLink;

@end


@interface Clicktale : NSObject

@property(nonatomic, assign) BOOL shouldWaitForLocation;
@property(nonatomic, assign) BOOL shouldStartLocationManager;

@property(nonatomic, strong) NSString *accessKey;
@property(nonatomic, strong) NSString *secretKey;
@property(nonatomic, strong) NSDictionary *userDefinedDictionary;
@property(nonatomic, strong) NSString *userID;

@property(nonatomic, readonly) NSString *SDKVersion;
@property(nonatomic, assign) CT_LOG_LEVEL logLevel;
@property(nonatomic, assign) int dispatchInterval;
@property(nonatomic, assign) id<ClicktaleDelegate> delegate;


#pragma mark initialization methods
#pragma mark ----------------------
/* Returns the default singleton instance.
 
 @return Clicktale shared instance
 */
+ (Clicktale *) sharedInstance;

/**
 *Sets Clicktale Access Key and Secret Key
 *
 *@param access_key NSString Application Access Key .
 *@param secretKey  NSString Application Secret Key.
 */
-(void)setAccessKey:(NSString *)access_key secretKey:(NSString *)secretKey;

/**
 Starts SDK to record and track all events.
 */
-(void)startClicktale;

/**
 Sets a UserID, so you can easily find sessions in the dashboard
 
 @param userID NSString The custom userID you want to set.
 */
-(void)setSessionUserID:(NSString *)userID;

/**
 Sets a user defined dictionary for every session.
 
 @param dict NSDictionary The custom data you want to set for this session.
 */
-(void)setPreDefinedDictionaryForSession:(NSDictionary *)dict;

/**
 Pause Screen Recording
 */
-(void)pauseScreenRecording;

/**
 Resume Screen Recording
 */
-(void)resumeScreenRecording;

/**
 Check if screen is Recorded
 
 @return BOOL is screen recorded
 */
-(BOOL)isScreenRecorded;


#pragma mark tracking methods
#pragma mark ----------------------


/**
 A custom track page method.
 You have to set the page's name.
 
 @param name NSString Page name.
 */
-(void)trackPageView:(NSString *)name;

/**
 A simple track event method.
 Log your custom events with this function
 
 @param event NSString event name.
 */
-(void)trackEvent:(NSString *)event;

/**
 A custom track event method.
 Log your custom events with values with this function
 
 @param event NSString event name.
 @param value NSString event's value.
 */
-(void)trackEvent:(NSString *)event value:(NSString *)value;

/**
 A custom track event method.
 Log Push Notification with this function
 
 @param launchOptions NSDictionary data from push notification (UIApplicationLaunchOptionsRemoteNotificationKey).
 */
-(void)trackPushNotificationOpeningWithLaunchOptions:(NSDictionary *)launchOptions;

/**
 A custom track event method.
 Log backgound Push Notification with this function
 
 @param userInfo NSDictionary data from push notification.
 */
-(void)trackPushNotificationBackgroundWithUserInfo:(NSDictionary *)userInfo;

/**
 A custom track event method.
 Log geo location with this function
 
 @param location CLLocation laction data.
 */
-(void)trackgGeoLocation:(CLLocation *)location;


#pragma mark privacy methods
#pragma mark ----------------------

/**
 Start hiding all of the screen
 A Black screen will be showen in the video
 */
-(void)startHidingScreen;

/**
 Stop Hiding all of the screen
 */
-(void)stopHidingScreen;

/**
 Check if screen is hidden
 
 @return BOOL is screen hidden
 */
-(BOOL)isScreenHidden;

/**
 Start hiding UIView & UITextField collection
 
 @param views NSArray array of views you want to hide.
 */
-(void)startPrivacyForViews:(NSArray <UIView *> *)views;

/**
 Stop hiding  UIView & UITextField
 
 @param views NSArray array of views you want to stop hiding.
 */
-(void)stopPrivacyForViews:(NSArray <UIView *> *)views;

/**
 Stop hiding All  UIView & UITextField collection
 */
-(void)stopPrivacyForAllViews;

/**
 Start hiding WebViews collection (UIWebView Or WKWebView)
 that has elements with ClassName 'ctHidden' and zoom is NOT enabled
 
 @param views NSArray array of WebViews you want to hide.
 */
-(void)startPrivacyForWebViews:(NSArray *)views;

/**
 Stop hiding WebViews
 
 @param views NSArray array of views you want to stop hiding.
 */
-(void)stopPrivacyForWebViews:(NSArray *)views;

/**
 Stop hiding All WebViews collection
 */
-(void)stopPrivacyForAllWebViews;

/**
 Stop hiding All UIViews and UITextfields and WebViews collection you added
 */
-(void)stopPrivacyForAll;

#pragma mark util methods
#pragma mark ----------------------


/**
 Current session dashboard URL
 
 @return NSString  dashboard URL.
 */
-(NSString *)getSessionLink;

/**
 Current session ID
 
 @return NSString Session ID.
 */
-(NSString *)getSessionID;

/**
 Save the device token to send push messages from Clicktale
 
 @param deviceToken NSData Device push notification token.
 */
-(void)setDeviceTokenFromData:(NSData *)deviceToken;

/**
 Check for are access keys set.
 
 @return BOOL is the application access Key set
 */
-(BOOL)isAccessKeysSet;

/**
 SDK has a stopwatch, so it returns current seconds for current session.
 If a session ends, stopwatch will be reset.
 */
-(NSTimeInterval)getRunTime;

/**
 Set Debug Mode on/off
 When debug mode on,the SDK will save videos to Photos Album before uploading it to server
 (15 seconds after application goes to background)
 
 @param on BOOL YES- Debug mode on/ NO- Debug mode off - default is NO
 */
-(void)setDebugMode:(BOOL)on;

@end


